import React, { useEffect } from "react";
import { useState } from "react";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import "./register.css";
import { Link } from "react-router-dom";
import { db } from "../../../Config/Config";
import { addDoc, collection, getDocs } from "firebase/firestore";

// import FileBase64 from "react-file-base64";

const Register = () => {
  const [formFields, setFormFields] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    gender: "",
    address: "",
    city: "",
    state: "",
    zipcode: "",
  });
  const [errors, setErrors] = useState({});
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormFields((prev) => {
      return {
        ...prev,
        [name]: value,
      };
    });

    // console.log(formFields);
  };
  // useEffect(() => {
  //   const createNewUser = async () => {
  //     const newUser = await getDocs(collection(db, "Users"));
  //     const userArr = newUser.docs.map((doc) => {
  //       return {
  //         ...doc.data(),
  //         id: doc.id,
  //       };
  //     });
  //     setCreateUser(userArr);
  //   };
  //   createNewUser();
  // }, []);

  const handleSubmit = async (e) => {
    try {
      e.preventDefault();
      const validationErrors = validateForm();

      if (Object.keys(validationErrors).length === 0) {
        console.log("Form submitted:", formFields);
        await addDoc(collection(db, "Users"), { ...formFields });
        alert("user creater successfully");
        // window.location.href = "/signIn";
        setErrors({});
      } else {
        setErrors(validationErrors);
      }
    } catch (error) {
      console.log(error);
    }
  };
  const validateForm = () => {
    let validationErrors = {};
    // validation
    if (!formFields.firstName) {
      validationErrors.firstName = `first Name required *`;
    }
    if (!formFields.lastName) {
      validationErrors.lastName = `last Name required *`;
    }
    if (!formFields.email) {
      validationErrors.email = `email required *`;
    } else if (
      !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(formFields.email)
    ) {
      validationErrors.email = `Email is invalid *`;
    }
    if (!formFields.password) {
      validationErrors.password = `Enter password`;
    } else if (
      !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(formFields.password)
    ) {
      validationErrors.password = `At least 8 characters long,
Contains at least one uppercase letter,
Contains at least one lowercase letter,
Contains at least one digit,
Allows special characters`;
    }
    if (!formFields.confirmPassword) {
      validationErrors.confirmPassword = `Enter confirm password`;
    } else if (formFields.password !== formFields.confirmPassword) {
      validationErrors.confirmPassword = `Password and confirm Password not same `;
    }
    if (formFields.gender === "") {
      validationErrors.gender = `select gender`;
    }
    if (!formFields.address) {
      validationErrors.address = `Address required`;
    }
    if (!formFields.city) {
      validationErrors.city = `city required`;
    }
    if (formFields.state === "") {
      validationErrors.state = `State required`;
    }
    if (!formFields.zipcode) {
      validationErrors.zipcode = `zipcode required `;
    } else if (formFields.zipcode.trim().length !== 6) {
      validationErrors.zipcode = `zipcode must 6 character only`;
    }
    return validationErrors;
  };

  return (
    <div className="reg-form w-50">
      <Form onSubmit={handleSubmit}>
        <h1 className="text-center">SignUp Form</h1>
        <Row className="mb-3">
          <Col>
            <Form.Label>First Name</Form.Label>
            <Form.Control
              placeholder="First name"
              name="firstName"
              value={formFields.firstName}
              onChange={handleChange}
            />
            {errors.firstName && (
              <p className="message text-danger">{errors.firstName}</p>
            )}
          </Col>
          <Col>
            <Form.Label>Last Name</Form.Label>
            <Form.Control
              placeholder="Last name"
              name="lastName"
              value={formFields.lastName}
              onChange={handleChange}
            />
            {errors.lastName && (
              <p className="message text-danger">{errors.lastName}</p>
            )}
          </Col>
        </Row>

        <Form.Group as={Col} controlId="formGridEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            name="email"
            value={formFields.email}
            onChange={handleChange}
          />
          {errors.email && (
            <p className="message text-danger">{errors.email}</p>
          )}
        </Form.Group>
        <Row className="mb-3">
          <Form.Group as={Col} controlId="formGridPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              name="password"
              value={formFields.password}
              onChange={handleChange}
            />
            {errors.password && (
              <p className="message text-danger">{errors.password}</p>
            )}
          </Form.Group>
          <Form.Group as={Col} controlId="formGridCPassword">
            <Form.Label>Confirm Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Confirm Password"
              name="confirmPassword"
              value={formFields.confirmPassword}
              onChange={handleChange}
            />
            {errors.confirmPassword && (
              <p className="message text-danger">{errors.confirmPassword}</p>
            )}
          </Form.Group>
        </Row>
        <fieldset>
          <Form.Group as={Row} className="mb-3">
            <Col sm={2}>
              <Form.Label as="legend" column sm={2}>
                Gender
              </Form.Label>
            </Col>
            <Col sm={2}>
              <Form.Check
                type="radio"
                label="Male"
                name="gender"
                value="male"
                id="formHorizontalRadios1"
                onChange={handleChange}
              />
            </Col>
            <Col sm={2}>
              <Form.Check
                type="radio"
                label="Female"
                name="gender"
                value="female"
                id="formHorizontalRadios2"
                onChange={handleChange}
              />
            </Col>
            <Col sm={2}>
              <Form.Check
                type="radio"
                label="others"
                name="gender"
                value="other"
                id="formHorizontalRadios3"
                onChange={handleChange}
              />
            </Col>
          </Form.Group>
          {errors.gender && (
            <p className="message text-danger">{errors.gender}</p>
          )}
        </fieldset>

        <Form.Group className="mb-3" controlId="formGridAddress1">
          <Form.Label>Address</Form.Label>
          <Form.Control
            placeholder="1234 Main St"
            name="address"
            value={formFields.address}
            onChange={handleChange}
          />
          {errors.address && (
            <p className="message text-danger">{errors.address}</p>
          )}
        </Form.Group>
        <Row className="mb-3">
          <Form.Group as={Col} controlId="formGridCity">
            <Form.Label>City</Form.Label>
            <Form.Control
              name="city"
              value={formFields.city}
              onChange={handleChange}
            />
            {errors.city && (
              <p className="message text-danger">{errors.city}</p>
            )}
          </Form.Group>

          <Form.Group as={Col} controlId="formGridState">
            <Form.Label>State</Form.Label>
            <Form.Select
              defaultValue="Choose..."
              name="state"
              onChange={handleChange}
            >
              <option value="">Choose...</option>
              <option value="Andhra Pradesh">Andhra Pradesh</option>
              <option value="Arunachal Pradesh">Arunachal Pradesh</option>
              <option value="Assam">Assam</option>
              <option value="Bihar">Bihar</option>
              <option value="Chhattisgarh">Chhattisgarh</option>
              <option value="Goa">Goa</option>
              <option value="Gujarat">Gujarat</option>
              <option value="Haryana">Haryana</option>
              <option value="Himachal Pradesh">Himachal Pradesh</option>
              <option value="Jharkhand">Jharkhand</option>
              <option value="Karnataka">Karnataka</option>
              <option value="Kerala">Kerala</option>
              <option value="Madhya Pradesh">Madhya Pradesh</option>
              <option value="Maharashtra">Maharashtra</option>
              <option value="Manipur">Manipur</option>
              <option value="Meghalaya">Meghalaya</option>
              <option value="Mizoram">Mizoram</option>
              <option value="Nagaland">Nagaland</option>
              <option value="Odisha">Odisha</option>
              <option value="Punjab">Punjab</option>
              <option value="Rajasthan">Rajasthan</option>
              <option value="Sikkim">Sikkim</option>
              <option value="Tamil Nadu">Tamil Nadu</option>
              <option value="Telangana">Telangana</option>
              <option value="Tripura">Tripura</option>
              <option value="Uttar Pradesh">Uttar Pradesh</option>
              <option value="Uttarakhand">Uttarakhand</option>
              <option value="West Bengal">West Bengal</option>
              <option value="Andaman and Nicobar Islands">
                Andaman and Nicobar Islands
              </option>
              <option value="Chandigarh">Chandigarh</option>
              <option value="Dadra and Nagar Haveli">
                Dadra and Nagar Haveli
              </option>
              <option value="Daman and Diu">Daman and Diu</option>
              <option value="Delhi">Delhi</option>
              <option value="Lakshadweep">Lakshadweep</option>
              <option value="Puducherry">Puducherry</option>{" "}
            </Form.Select>
            {errors.state && (
              <p className="message text-danger">{errors.state}</p>
            )}
          </Form.Group>

          <Form.Group as={Col} controlId="formGridZip">
            <Form.Label>Zip</Form.Label>
            <Form.Control
              name="zipcode"
              value={formFields.zipcode}
              onChange={handleChange}
            />
            {errors.zipcode && (
              <p className="message text-danger">{errors.zipcode}</p>
            )}
          </Form.Group>
        </Row>

        <Form.Group className="mb-3" id="formGridCheckbox">
          <Form.Check
            type="checkbox"
            label="Agree and continue."
            name="checkIn"
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>
            Already have account.<Link to="/signIn">Click here.</Link>
          </Form.Label>
        </Form.Group>
        <Button variant="primary" type="submit">
          Submit
        </Button>
      </Form>
    </div>
  );
};

export default Register;
